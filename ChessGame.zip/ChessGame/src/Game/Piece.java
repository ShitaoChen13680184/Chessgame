package Game;

public enum Piece {
    ROOK, KNIGHT,PAWN,BISHOP,KING,QUEEN
}
