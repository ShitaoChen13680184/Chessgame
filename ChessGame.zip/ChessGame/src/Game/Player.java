package Game;

public enum Player {
	BLACK,WHITE
}
