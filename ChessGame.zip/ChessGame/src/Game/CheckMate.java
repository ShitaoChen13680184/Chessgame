package Game;
import Board.Board;
import Board.Unit;
import Pieces.*;

public class CheckMate {

	private static Unit[][] units = Board.getUnit();
	public static boolean checkMate(King king){
		ChessPiece cp;
		Player player =king.getPlayer();
		
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				
				cp =units[i][j].getCp();

				if(cp!=null && (player!=cp.player)){ //if the current box is not null and it's the enemy piece then see possible moves from them
					if(cp instanceof Rook) ((Rook)cp).validCheckMateMoves();
					else if(cp instanceof Knight) ((Knight)cp).validCheckMateMoves();
					else if(cp instanceof Bishop) ((Bishop)cp).validCheckMateMoves();
					else if(cp instanceof Queen) ((Queen)cp).validCheckMateMoves();
					else if(cp instanceof Pawn) ((Pawn)cp).validCheckMateMoves(king.getOppPlayer()); //pawn needs to get the moves from the opposite team pieces
					//gets valid check mate moves from other king
					else if(cp instanceof King) ((King)cp).validCheckMateMoves();
					
				}
			}
		}
		int x = king.x;
		int y = king.y;
		int[][] kingCells = {{x-1,x,x+1},{y-1,y,y+1}};
		int numberOfBoxes=9;
		for(int i =0;i<3;i++){
			for(int j=0;j<3;j++){
				//check if the numbers are out of index
				if(kingCells[0][i]<8 && kingCells[0][i]>=0 && kingCells[1][j]<8 && kingCells[1][j]>=0 ){
					//if one of the king's box can be reached by other enemy piece, then delete that box
					if(units[kingCells[0][i]][kingCells[1][j]].getCheckMateMove()==true || units[x][y].sameTK(units[kingCells[0][i]][kingCells[1][j]])){
						numberOfBoxes--;
					}
				} else{
					
					numberOfBoxes--;
				}
			}
		
		}

		if(numberOfBoxes==0) {
			return true;

		}		
		return false;
		
	}
	
	public static void resetCheckMateMoves(){
		
		Unit unit;
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				
				unit=units[i][j];
				if(unit!=null) unit.setCheckMateMove(false);
		
			}
		}
	}
	
}