package Game;
import Board.BoardFrame;

public class Game {
	public static void main(String[] args) {
		BoardFrame boardframe = new BoardFrame();
	}
}
