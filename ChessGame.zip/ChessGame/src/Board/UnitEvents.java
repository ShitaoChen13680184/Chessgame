package Board;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

import Pieces.*;
import Game.CheckMate;
import Pieces.ChessPiece;
import Game.Player;

public class UnitEvents implements ActionListener{
	
	private Unit[][] units=Board.getUnit();
	boolean readyToMove=false;
	private Unit previous = null;
	private Player previousPlayer=null;
	
	public void actionPerformed(ActionEvent e) {

		Object source = e.getSource();
		
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				Unit unit = units[i][j];
				if(source ==unit){
					ChessPiece piece = unit.getCp();
					if(readyToMove ==true){
						readyToMove=false;
						if(units[i][j].getValidMove()==true){
							
							//previous piece
							ChessPiece previousPiece = previous.getCp();

							if(previousPiece!=null && previousPiece!=unit.getCp()){
								//check if it's castling
								if(piece!=null && previousPiece.player==piece.player){
									piece.move(previousPiece.x, previousPiece.y);
									previousPiece.move(i, j);
									units[i][j].setPiece(previousPiece);
									previous.setPiece(piece);
									previousPlayer=previous.getCp().player;
								}
								else{
									previousPiece.move(i, j);
									units[i][j].setPiece(previousPiece);
									previousPlayer=previous.getCp().player;
									previous.setPiece(null);
									previous=null;
								}
								//pawn promotion
								if(previousPiece instanceof Pawn ){

								}
								else if(previousPiece instanceof King){
									((King)previousPiece).moved= true;
								}
								else if  (previousPiece instanceof Rook){
									((Rook)previousPiece).moved=true;
								}
							}
						
						}

						Board.reColorUnits();//recolor the board and set valid moves(highlighted) to null
					}
					
					//compares the player now and previous
					else if(piece instanceof Rook &&previousPlayer!=piece.player){
						readyToMove=((Rook) piece).validMoves();
						previous = units[i][j];
					}
					else if(piece instanceof Knight &&previousPlayer!=piece.player){
						readyToMove=((Knight) piece).validMoves();
						previous = units[i][j];
					}
					else if(piece instanceof Bishop &&previousPlayer!=piece.player){

						readyToMove=((Bishop)piece).validMoves();
						previous =units[i][j];
					}
					else if(piece instanceof Queen &&previousPlayer!=piece.player){

						readyToMove=((Queen) piece).validMoves();
						previous = units[i][j];
					}
					else if(piece instanceof Pawn &&previousPlayer!=piece.player){

						readyToMove=((Pawn) piece).validMoves();
						previous = units[i][j];
					}
					
					else if(piece instanceof King && piece.player==Player.WHITE && previousPlayer!=piece.player){
						CheckMate.checkMate(Board.kw);
						King king = (King)piece;
						readyToMove= king.validMoves();
						if(king.moved==false){
							king.validCastle(Player.WHITE);
						}
						previous = units[i][j];
						CheckMate.resetCheckMateMoves();
						
						}
					
					else if(piece instanceof King && piece.player==Player.BLACK && previousPlayer!=piece.player){
						CheckMate.checkMate(Board.kb);
						King king = (King)piece;
						readyToMove= king.validMoves();
						if(king.moved==false){
							king.validCastle(Player.BLACK);
						}
						previous = units[i][j];
						CheckMate.resetCheckMateMoves();
					}
					if(CheckMate.checkMate(Board.kb)){
						JOptionPane.showMessageDialog(null, "White Wins!");
						return;
					}
					else CheckMate.resetCheckMateMoves();
					if(CheckMate.checkMate(Board.kw)){
						JOptionPane.showMessageDialog(null, "Black Wins!");
						return;
					}
					else CheckMate.resetCheckMateMoves();
					
				}
			}
		}
		
		
	}

}
