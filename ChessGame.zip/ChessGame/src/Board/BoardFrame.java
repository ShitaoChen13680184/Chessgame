package Board;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class BoardFrame extends JFrame{
	public BoardFrame(){
		this.setTitle("Functional Chess Game");
		JPanel p = new Board();
		this.add(p);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(600,600);
		this.setResizable(false);
		this.setLocationRelativeTo(null);

	}
	
}
