package Board;
import Pieces.ChessPiece;
import Game.Piece;

import java.awt.Color;
import javax.swing.JButton;

public class Unit extends JButton {

	private ChessPiece cp = null ;
	private boolean validMove = false ;
	private boolean checkMateMove = false;

	public ChessPiece getCp(){
		return cp;
	}

	public void setValidMove(boolean Valid){
		if(Valid)
			this.setBackground(Color.green);
		validMove=Valid;
	}

	public void setCheckMateMove(boolean Valid){
		checkMateMove=Valid;
	}

	public boolean getValidMove(){
		return validMove;
	}
	
	public boolean getCheckMateMove(){
		return checkMateMove;
	}
	
	
	public void setPiece(ChessPiece chessPiece){
			if( chessPiece==null){
				cp=null;
				this.setIcon(null);
			}
			else{
				cp=chessPiece;
				this.setIcon(chessPiece.getImage());
			}
			
	}
	

	public boolean sameT(Unit unit){
		if(unit.cp==null)
			return false;
		else if(cp.player==unit.cp.player)
			return true;
		else
			return false;
	}
	public boolean sameTK(Unit unit){
		if(unit.cp==null || unit.cp.piece== Piece.KING)
			return false;
		else if(cp.getPlayer()==unit.cp.player){
			return true;
		}
		else
			return false;
	}
	
	public boolean oppT(Unit unit){
		if(unit.cp==null || cp==null)
			return false;
		else if(cp.getOppPlayer()==unit.cp.player){
			return true;
		}
		else
			return false;
	}
	
	public boolean oppTK(Unit unit){
		if(unit.cp==null || unit.cp.piece==Piece.KING)
			return false;
		else if(cp.getOppPlayer()==unit.cp.player){
			return true;
		}
		else
			return false;
	}
	
	public void setColor(boolean color){
		if(color){
			this.setBackground(Color.DARK_GRAY);
		}
		else{
			this.setBackground(Color.WHITE);
		}
	}
	
}
