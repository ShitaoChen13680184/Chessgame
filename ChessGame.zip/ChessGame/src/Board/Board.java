package Board;

import java.awt.*;
import javax.swing.*;
import Pieces.*;
import Pieces.ChessPiece;
import Game.Player;
import Game.Piece;

public class Board extends JPanel{
	
	public static Unit[][] units;
	
	public Board(){
		units = new Unit[8][8];
		this.setLayout(new GridLayout(8,8));
		setUpUnits();
		setUpPieces();
		initializePieces();
	}
	
	public static Unit[][] getUnit(){
		return units;
	}
	
	public static void reColorUnits(){
		for(int i =0;i<8;i++){
			for(int j=0;j<8;j++){
				if((i+j)%2!=0){
					units[i][j].setColor(true);
				}
				else {
					units[i][j].setColor(false);
				}
				units[i][j].setValidMove(false);
			}
		}
	}
	
	
	public void setUpUnits(){
		UnitEvents unitEvents = new UnitEvents();
		for(int i =0;i<8;i++){
			for(int j=0;j<8;j++){
				units[i][j]=new Unit();
				if((i+j)%2!=0){
					units[i][j].setColor(true);
				}
				else
					units[i][j].setColor(false);
				
				this.add(units[i][j]);
				//add action listener
				units[i][j].addActionListener(unitEvents);
			}
		}
		
	}
	
	
	public static Rook rb1,rb2,rw1,rw2;
	public static King kb,kw;
	public static Queen qb,qw;
	public static Bishop bb1,bb2,bw1,bw2;
	public static Knight kb1,kb2,kw1,kw2;

	public static Pawn pb1,pb2,pb3,pb4,pb5,pb6,pb7,pb8;
	public static Pawn pw1,pw2,pw3,pw4,pw5,pw6,pw7,pw8;

	public void setUpPieces(){
		/* Rook: 2*/
		rb1 = new Rook(Piece.ROOK,0,0, Player.BLACK);
		rb2 = new Rook(Piece.ROOK,0,7,Player.BLACK);
		rw1 = new Rook(Piece.ROOK,7,0,Player.WHITE);
		rw2 = new Rook(Piece.ROOK,7,7,Player.WHITE);

		/* King: 1*/
		kb = new King(Piece.KING,0,3,Player.BLACK);
		kw = new King(Piece.KING,7,4,Player.WHITE);

		/* Queen: 1*/
		qb = new Queen(Piece.QUEEN,0,4,Player.BLACK);
		qw = new Queen(Piece.QUEEN,7,3,Player.WHITE);

		/* Bishop: 2*/
		bb1 = new Bishop(Piece.BISHOP,0,2,Player.BLACK);
		bb2 = new Bishop(Piece.BISHOP,0,5,Player.BLACK);
		bw1 = new Bishop(Piece.BISHOP,7,2,Player.WHITE);
		bw2 = new Bishop(Piece.BISHOP,7,5,Player.WHITE);

		/* Knight: 2*/
		kb1 = new Knight(Piece.KNIGHT,0,1,Player.BLACK);
		kb2 = new Knight(Piece.KNIGHT,0,6,Player.BLACK);
		kw1 = new Knight(Piece.KNIGHT,7,1,Player.WHITE);
		kw2 = new Knight(Piece.KNIGHT,7,6,Player.WHITE);

		/*Pawn: (8)*/
		pb1 = new Pawn(Piece.PAWN,1,0,Player.BLACK);
		pb2 = new Pawn(Piece.PAWN,1,1,Player.BLACK);
		pb3 = new Pawn(Piece.PAWN,1,2,Player.BLACK);
		pb4 = new Pawn(Piece.PAWN,1,3,Player.BLACK);
		pb5 = new Pawn(Piece.PAWN,1,4,Player.BLACK);
		pb6 = new Pawn(Piece.PAWN,1,5,Player.BLACK);
		pb7 = new Pawn(Piece.PAWN,1,6,Player.BLACK);
		pb8 = new Pawn(Piece.PAWN,1,7,Player.BLACK);

		pw1 = new Pawn(Piece.PAWN,6,0,Player.WHITE);
		pw2 = new Pawn(Piece.PAWN,6,1,Player.WHITE);
		pw3 = new Pawn(Piece.PAWN,6,2,Player.WHITE);
		pw4 = new Pawn(Piece.PAWN,6,3,Player.WHITE);
		pw5 = new Pawn(Piece.PAWN,6,4,Player.WHITE);
		pw6 = new Pawn(Piece.PAWN,6,5,Player.WHITE);
		pw7 = new Pawn(Piece.PAWN,6,6,Player.WHITE);
		pw8 = new Pawn(Piece.PAWN,6,7,Player.WHITE);
		
	}
	
	public void initializePieces(){

		ChessPiece[] pieces = {rb1,rb2,rw1,rw2,kb1,kb2,kw1,kw2,bb1,bb2,bw1,bw2,qb,qw,
				kb,kw,pb1,pb2,pb3,pb4,pb5,pb6,pb7,pb8,pw1,pw2,pw3,pw4,pw5,pw6,pw7,pw8};
		
		for(int i=0;i<32;i++){
			ChessPiece cp = pieces[i];
			units[cp.x][cp.y].setPiece(pieces[i]);
		}
		
	}	
	
	
}
