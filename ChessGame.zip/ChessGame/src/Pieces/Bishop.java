package Pieces;
import Board.Board;
import Board.Unit;
import Game.Player;
import Game.Piece;


public class Bishop extends ChessPiece {
	
	private Unit[][] units;
	
	public Bishop(Piece bishop, int x, int y, Player player){
		super(bishop, x,y,player);
		if(player==Player.BLACK){
			image = reSize("/bb.png");
		}
		else if(player==Player.WHITE)
			image = reSize("/bw.png");
	}
	
	public boolean validMoves(){
		
		units= Board.getUnit();

		for(int i =1;i<8;i++){
			if(x+i<8 && y+i<8 && !units[x][y].sameT(units[x+i][y+i])){
				units[x+i][y+i].setValidMove(true);
				
				if(x+i+1<8 && y+i+1<8 &&units[x][y].sameT(units[x+i+1][y+i+1])) break;
				
				if(x+i<8 && y+i<8 && units[x][y].oppT(units[x+i][y+i])) break;
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x+i<8 && y-i>=0 && !units[x][y].sameT(units[x+i][y-i])){
				units[x+i][y-i].setValidMove(true);
				
				if(x+i+1<8 && y-i-1>=0 && units[x][y].sameT(units[x+i+1][y-i-1])) break;
				
				if(x+i<8 && y-i>=0 && units[x][y].oppT(units[x+i][y-i])) break;
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y+i<8 && !units[x][y].sameT(units[x-i][y+i])){
				units[x-i][y+i].setValidMove(true);
				
				if(x-i-1>=0 && y+i+1<8 && units[x][y].sameT(units[x-i-1][y+i+1])) break;
				
				if(x-i>=0 && y+i<8 && units[x][y].oppT(units[x-i][y+i])) break;
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y-i>=0 && !units[x][y].sameT(units[x-i][y-i])){
				units[x-i][y-i].setValidMove(true);
				
				if(x-i-1>=0 && y-i-1>=0 && units[x][y].sameT(units[x-i-1][y-i-1]))	break;
				
				if(x-i>=0 && y-1>=0 && units[x][y].oppT(units[x-i][y-i])) break;
				
			}
			else break;
		}
		
		return true;
	}
	
	public boolean validCheckMateMoves(){
		
		units= Board.getUnit();

		for(int i =1;i<8;i++){

			if(x+i<8 && y+i<8 && !units[x][y].sameT(units[x+i][y+i]) && !units[x][y].oppTK(units[x+i][y+i])){
				units[x+i][y+i].setCheckMateMove(true);
				if(x+i+1<8 && y+i+1<8 &&units[x][y].sameT(units[x+i+1][y+i+1])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x+i<8 && y-i>=0 && !units[x][y].sameT(units[x+i][y-i]) && !units[x][y].oppTK(units[x+i][y-i])){
				units[x+i][y-i].setCheckMateMove(true);
				
				if(x+i+1<8 && y-i-1>=0 && units[x][y].sameT(units[x+i+1][y-i-1])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y+i<8 && !units[x][y].sameT(units[x-i][y+i]) && !units[x][y].oppTK(units[x-i][y+i])){
				units[x-i][y+i].setCheckMateMove(true);
				
				if(x-i-1>=0 && y+i+1<8 && units[x][y].sameT(units[x-i-1][y+i+1])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y-i>=0 && !units[x][y].sameT(units[x-i][y-i])&& !units[x][y].oppTK(units[x-i][y-i])){
				units[x-i][y-i].setCheckMateMove(true);
				
				if(x-i-1>=0 && y-i-1>=0 && units[x][y].sameT(units[x-i-1][y-i-1]))	break;
				
			}
			else break;
		}
			
		return true;
	}
	
	
}
