package Pieces;

import Board.Board;
import Board.Unit;
import Game.Player;
import Game.Piece;


public class Rook extends ChessPiece {

	private Unit[][] units;
	public boolean moved= false;
	
	public Rook(Piece rook, int x, int y, Player player){
		super(rook, x, y,player);
		if(player==Player.BLACK){
			image = reSize("/rb.png");
		}
		else if(player==Player.WHITE)
			image = reSize("/rw.png");
	}

	//Highlights valid moves
	public boolean validMoves(){
		
		units = Board.getUnit();
		for(int i=1;i<8;i++){
			
			//if the next unit is not on the same team as current unit, highlight the next unit first
			if(y+i<8 && !units[x][y].sameT(units[x][y+i])){
				units[x][y+i].setValidMove(true);
				
				//can't highlight the same slider
				if(y+i+1<8 && units[x][y].sameT(units[x][y+i+1])) break;
				
				//stop highlighting, since the next cell is already highlighted)
				else if(units[x][y].oppT(units[x][y+i])) break;
			}

			else break;
				
		}
		

		for(int i=1;i<8;i++){
				if(y-i>=0 && !units[x][y].sameT(units[x][y-i])){
					units[x][y-i].setValidMove(true);
				if(y-i-1>=0 && units[x][y].sameT(units[x][y-i-1])) break;
				else if(units[x][y].oppT(units[x][y-i])) break;
				}
				else break;
		}

		for(int i=1;i<8;i++){	
			
			if(x+i<8 && !units[x][y].sameT(units[x+i][y])){
				units[x+i][y].setValidMove(true);
				if(x+i+1<8 && units[x][y].sameT(units[x+i+1][y])) break;
				else if(units[x][y].oppT(units[x+i][y])) break;
				
			}
			
			else break;
		}

		for(int i=1;i<8;i++){	
			
			if(x-i>=0 && !units[x][y].sameT(units[x-i][y])){
				units[x-i][y].setValidMove(true);
				if(x-i-1>=0 && units[x][y].sameT(units[x-i-1][y])) break;
				else if(units[x][y].oppT(units[x-i][y])) break;
				
			}
			else break;
		}
		
		return true;
	}
	

	public boolean validCheckMateMoves(){

		units = Board.getUnit();
		for(int i=1;i<8;i++){

			if(y+i<8 && !units[x][y].sameT(units[x][y+i])){
				units[x][y+i].setCheckMateMove(true);
				
				//can't highlight the same team
				if(y+i+1<8 && units[x][y].sameT(units[x][y+i+1])) break;
				
				//stop highlighting immediately
				else if(units[x][y].oppTK(units[x][y+i])) break;
			}

			else break;
				
		}
		

		for(int i=1;i<8;i++){
				if(y-i>=0 && !units[x][y].sameT(units[x][y-i])){
					units[x][y-i].setCheckMateMove(true);
					
				if(y-i-1>=0 && units[x][y].sameT(units[x][y-i-1])) break;
				
				else if(units[x][y].oppTK(units[x][y-i])) break;
				}
				else break;
		}

		for(int i=1;i<8;i++){	
			
			if(x+i<8 && !units[x][y].sameT(units[x+i][y])){
				units[x+i][y].setCheckMateMove(true);
			
				if(x+i+1<8 && units[x][y].sameT(units[x+i+1][y])) break;
				
				else if(units[x][y].oppTK(units[x+i][y])) break;
				
			}
			
			else break;
		}

		for(int i=1;i<8;i++){	
			
			if(x-i>=0 && !units[x][y].sameT(units[x-i][y])){
				units[x-i][y].setCheckMateMove(true);
			
				if(x-i-1>=0 && units[x][y].sameT(units[x-i-1][y])) break;
				
				else if(units[x][y].oppTK(units[x-i][y])) break;
				
			}
			else break;
		}
		

		
		return true;
	}
	
}
