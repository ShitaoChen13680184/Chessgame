package Pieces;

import Board.Board;
import Board.Unit;
import Game.Player;
import Game.Piece;


public class King extends ChessPiece {
	
	private Unit[][] units;
	public boolean moved = false;
	
	public King(Piece king, int x, int y, Player player){
		super(king,x,y,player);
		if(player==Player.BLACK){
			image = reSize("/kb.png");
		}
		else if(player==Player.WHITE)
			image = reSize("/kw.png");
	}
	
	public boolean validMoves(){

		units = Board.getUnit();
		//the 9 cells that king can move to
		int[][] kingCells = {{x-1,x,x+1},{y-1,y,y+1}};

		units[x][y].setValidMove(true);

		//highlight
		for(int i =0;i<3;i++){
			for(int j=0;j<3;j++){
				if(kingCells[0][i]<8 && kingCells[0][i]>=0 && kingCells[1][j]<8 && kingCells[1][j]>=0)
					if(units[kingCells[0][i]][kingCells[1][j]].getCheckMateMove()==false && !units[x][y].sameT(units[kingCells[0][i]][kingCells[1][j]])){
						units[kingCells[0][i]][kingCells[1][j]].setValidMove(true);
					}
				}
		}
		
		return true;
	}

	public boolean validCheckMateMoves(){

		units = Board.getUnit();
		int[][] kingCells = {{x-1,x,x+1},{y-1,y,y+1}};
		
		//highlight
		for(int i =0;i<3;i++){
			for(int j=0;j<3;j++){

				if(kingCells[0][i]<8 && kingCells[0][i]>=0 && kingCells[1][j]<8 && kingCells[1][j]>=0)
					if(units[kingCells[0][i]][kingCells[1][j]].getCheckMateMove()==false && !units[x][y].sameT(units[kingCells[0][i]][kingCells[1][j]])
					&& !units[x][y].oppTK(units[kingCells[0][i]][kingCells[1][j]])){
						units[kingCells[0][i]][kingCells[1][j]].setCheckMateMove(true);
					}
				}
		}
		
		return true;
	}
	
	public void validCastle(Player player){

		if(player==Player.BLACK){

			ChessPiece cp= units[0][0].getCp(); //the first black rook

			if(cp!=null && cp instanceof Rook){			//piece can't be null
				if(((Rook)cp).moved==false){
					if(units[0][1].getCp()==null && units[0][2].getCp()==null && units[0][0].getCheckMateMove()==false){
						units[0][0].setValidMove(true);
					}
				}
			}
			cp = units[0][7].getCp();
			if(cp!=null && cp instanceof Rook){
				
				if(((Rook)cp).moved==false){
					if(units[0][4].getCp()==null && units[0][5].getCp()==null&& units[0][6].getCp()==null && units[0][7].getCheckMateMove()==false){
						units[0][7].setValidMove(true);
					}
				}
			}
		}
		
		else{
			ChessPiece temp= units[7][0].getCp();
			if(temp!=null && temp instanceof Rook){
				if(((Rook)temp).moved==false){
					if(units[7][1].getCp()==null && units[7][2].getCp()==null && units[7][3].getCp()==null && units[7][0].getCheckMateMove()==false){
						units[7][0].setValidMove(true);
					}
				}
			}
			temp = units[7][7].getCp();
			if(temp!=null && temp instanceof Rook){
				if(((Rook)temp).moved==false){
					if(units[7][5].getCp()==null && units[7][6].getCp()==null &&units[7][7].getCheckMateMove()==false ){
						units[7][7].setValidMove(true);
					}
				}
			}
		}
	}
	
	
	
}
