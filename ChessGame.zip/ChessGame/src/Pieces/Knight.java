package Pieces;

import Board.Board;
import Board.Unit;
import Game.Player;
import Game.Piece;

public class Knight extends ChessPiece {

	private Unit[][] units;
	
	public Knight(Piece knight, int x, int y, Player player){
		super(knight,x,y,player);
		if(player==Player.BLACK){
			image = reSize("/kb1.png");
		}
		else if(player==Player.WHITE)
			image = reSize("/kw1.png");
	}
	
	public boolean validMoves(){

		units= Board.getUnit();

		if(x+2<8 && y+1<8 && !units[x][y].sameT(units[x+2][y+1])){
			units[x+2][y+1].setValidMove(true);
		}

		if(x+2<8 && y-1>=0 && !units[x][y].sameT(units[x+2][y-1])){
			units[x+2][y-1].setValidMove(true);
		}

		if(x-2>=0 && y+1<8 && !units[x][y].sameT(units[x-2][y+1])){
			units[x-2][y+1].setValidMove(true);
		}

		if(x-2>=0 && y-1>=0 && !units[x][y].sameT(units[x-2][y-1])){
			units[x-2][y-1].setValidMove(true);
		}

		if(x-1>=0 && y+2<8 && !units[x][y].sameT(units[x-1][y+2])){
			units[x-1][y+2].setValidMove(true);
		}

		if(x+1<8 && y+2<8 && !units[x][y].sameT(units[x+1][y+2])){
			units[x+1][y+2].setValidMove(true);
		}

		if(x-1>=0 && y-2>=0 && !units[x][y].sameT(units[x-1][y-2])){
			units[x-1][y-2].setValidMove(true);
		}

		if(x+1<8 && y-2>=0 && !units[x][y].sameT(units[x+1][y-2])){
			units[x+1][y-2].setValidMove(true);
		}
				
		return true;
	}
	
	public boolean validCheckMateMoves(){

		units= Board.getUnit();

		if(x+2<8 && y+1<8 && !units[x][y].sameT(units[x+2][y+1])&& !units[x][y].oppTK(units[x+2][y+1])){
			units[x+2][y+1].setCheckMateMove(true);
		}

		if(x+2<8 && y-1>=0 && !units[x][y].sameT(units[x+2][y-1])&& !units[x][y].oppTK(units[x+2][y-1])){
			units[x+2][y-1].setCheckMateMove(true);
		}

		if(x-2>=0 && y+1<8 && !units[x][y].sameT(units[x-2][y+1])&& !units[x][y].oppTK(units[x-2][y+1])){
			units[x-2][y+1].setCheckMateMove(true);
		}

		if(x-2>=0 && y-1>=0 && !units[x][y].sameT(units[x-2][y-1])&& !units[x][y].oppTK(units[x-2][y-1])){
			units[x-2][y-1].setCheckMateMove(true);
		}

		if(x-1>=0 && y+2<8 && !units[x][y].sameT(units[x-1][y+2])&& !units[x][y].oppTK(units[x-1][y+2])){
			units[x-1][y+2].setCheckMateMove(true);
		}

		if(x+1<8 && y+2<8 && !units[x][y].sameT(units[x+1][y+2])&& !units[x][y].oppTK(units[x+1][y+2])){
			units[x+1][y+2].setCheckMateMove(true);
		}

		if(x-1>=0 && y-2>=0 && !units[x][y].sameT(units[x-1][y-2])&& !units[x][y].oppTK(units[x-1][y-2])){
			units[x-1][y-2].setCheckMateMove(true);
		}
		if(x+1<8 && y-2>=0 && !units[x][y].sameT(units[x+1][y-2])&& !units[x][y].oppTK(units[x+1][y-2])){
			units[x+1][y-2].setCheckMateMove(true);
		}
				
		return true;
	}
}
