package Pieces;

import Board.Board;
import Board.Unit;
import Game.Player;
import Game.Piece;

public class Queen extends ChessPiece {
	
	private Unit[][] units;
	
	public Queen(Piece queen, int x , int y, Player player){
		super(queen,x,y,player);
		if(player==Player.BLACK){
			image = reSize("/qb.png");
		}
		else if(player==Player.WHITE)
			image = reSize("/qw.png");
	}
	
	public boolean validMoves(){

		units = Board.getUnit();
		//rook properties
		for(int i=1;i<8;i++){

			if(y+i<8 && !units[x][y].sameT(units[x][y+i])){
				units[x][y+i].setValidMove(true);

				if(y+i+1<8 && units[x][y].sameT(units[x][y+i+1])) break;

				else if(units[x][y].oppT(units[x][y+i])) break;
			}
			else break;
				
		}
		

		for(int i=1;i<8;i++){
				if(y-i>=0 && !units[x][y].sameT(units[x][y-i])){
					units[x][y-i].setValidMove(true);
					
				if(y-i-1>=0 && units[x][y].sameT(units[x][y-i-1])) break;
				
				else if(units[x][y].oppT(units[x][y-i])) break;
				}
				else break;
		}
		

		for(int i=1;i<8;i++){	
			
			if(x+i<8 && !units[x][y].sameT(units[x+i][y])){
				units[x+i][y].setValidMove(true);
			
				if(x+i+1<8 && units[x][y].sameT(units[x+i+1][y])) break;
				
				else if(units[x][y].oppT(units[x+i][y])) break;
				
			}
			else break;
		}

		for(int i=1;i<8;i++){	
			
			if(x-i>=0 && !units[x][y].sameT(units[x-i][y])){
				units[x-i][y].setValidMove(true);
			
				if(x-i-1>=0 && units[x][y].sameT(units[x-i-1][y])) break;
				
				else if(units[x][y].oppT(units[x-i][y])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x+i<8 && y+i<8 && !units[x][y].sameT(units[x+i][y+i])){
				units[x+i][y+i].setValidMove(true);
				
				if(x+i+1<8 && y+i+1<8 &&units[x][y].sameT(units[x+i+1][y+i+1])) break;
				
				if(x+i<8 && y+i<8 && units[x][y].oppT(units[x+i][y+i])) break;
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x+i<8 && y-i>=0 && !units[x][y].sameT(units[x+i][y-i])){
				units[x+i][y-i].setValidMove(true);
				
				if(x+i+1<8 && y-i-1>=0 && units[x][y].sameT(units[x+i+1][y-i-1])) break;
				
				if(x+i<8 && y-i>=0 && units[x][y].oppT(units[x+i][y-i])) break;
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y+i<8 && !units[x][y].sameT(units[x-i][y+i])){
				units[x-i][y+i].setValidMove(true);
				
				if(x-i-1>=0 && y+i+1<8 && units[x][y].sameT(units[x-i-1][y+i+1])) break;
				
				if(x-i>=0 && y+i<8 && units[x][y].oppT(units[x-i][y+i])) break;
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y-i>=0 && !units[x][y].sameT(units[x-i][y-i])){
				units[x-i][y-i].setValidMove(true);
				
				if(x-i-1>=0 && y-i-1>=0 && units[x][y].sameT(units[x-i-1][y-i-1]))	break;
				
				if(x-i>=0 && y-1>=0 && units[x][y].oppT(units[x-i][y-i])) break;
				
			}
			else break;
		}
		return true;
	}

	public boolean validCheckMateMoves(){
		units = Board.getUnit();
		for(int i=1;i<8;i++){

			if(y+i<8 && !units[x][y].sameT(units[x][y+i])){
				units[x][y+i].setCheckMateMove(true);

				if(y+i+1<8 && units[x][y].sameT(units[x][y+i+1])) break;

				else if(units[x][y].oppTK(units[x][y+i])) break;
			}

			else break;
				
		}

		for(int i=1;i<8;i++){
				if(y-i>=0 && !units[x][y].sameT(units[x][y-i])){
					units[x][y-i].setCheckMateMove(true);
					
				if(y-i-1>=0 && units[x][y].sameT(units[x][y-i-1])) break;
				
				else if(units[x][y].oppTK(units[x][y-i])) break;
				}
				else break;
		}
		for(int i=1;i<8;i++){	
			
			if(x+i<8 && !units[x][y].sameT(units[x+i][y])){
				units[x+i][y].setCheckMateMove(true);
			
				if(x+i+1<8 && units[x][y].sameT(units[x+i+1][y])) break;
				
				else if(units[x][y].oppTK(units[x+i][y])) break;
				
			}
			
			else break;
		}
		for(int i=1;i<8;i++){	
			
			if(x-i>=0 && !units[x][y].sameT(units[x-i][y])){
				units[x-i][y].setCheckMateMove(true);
			
				if(x-i-1>=0 && units[x][y].sameT(units[x-i-1][y])) break;
				
				else if(units[x][y].oppTK(units[x-i][y])) break;
				
			}
			else break;
		}

		for(int i =1;i<8;i++){

			if(x+i<8 && y+i<8 && !units[x][y].sameT(units[x+i][y+i]) && !units[x][y].oppTK(units[x+i][y+i])){
				units[x+i][y+i].setCheckMateMove(true);
				
				if(x+i+1<8 && y+i+1<8 &&units[x][y].sameT(units[x+i+1][y+i+1])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x+i<8 && y-i>=0 && !units[x][y].sameT(units[x+i][y-i]) && !units[x][y].oppTK(units[x+i][y-i])){
				units[x+i][y-i].setCheckMateMove(true);
				
				if(x+i+1<8 && y-i-1>=0 && units[x][y].sameT(units[x+i+1][y-i-1])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y+i<8 && !units[x][y].sameT(units[x-i][y+i]) && !units[x][y].oppTK(units[x-i][y+i])){
				units[x-i][y+i].setCheckMateMove(true);
				
				if(x-i-1>=0 && y+i+1<8 && units[x][y].sameT(units[x-i-1][y+i+1])) break;
				
			}
			else break;
		}
		

		for(int i =1;i<8;i++){
			if(x-i>=0 && y-i>=0 && !units[x][y].sameT(units[x-i][y-i])&& !units[x][y].oppTK(units[x-i][y-i])){
				units[x-i][y-i].setCheckMateMove(true);
				
				if(x-i-1>=0 && y-i-1>=0 && units[x][y].sameT(units[x-i-1][y-i-1]))	break;
				
			}
			else break;
		}
		
		
		return true;
	}
}
