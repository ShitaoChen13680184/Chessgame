package Pieces;

import Board.Board;
import Board.Unit;
import Game.Player;
import Game.Piece;

public class Pawn extends ChessPiece {
	
	private Unit[][] units;
	
	public Pawn(Piece pawn, int x, int y, Player player){
		super(pawn, x,y,player);
		if(player==Player.BLACK){
			image = reSize("/pb.png");
		}
		else if(player==Player.WHITE)
			image = reSize("/pw.png");
	}
	
	public boolean validMoves(){
		
		units = Board.getUnit();
		
		if(player==Player.BLACK){

			for(int i =1;i<3;i++){
				if(x+i<8 && units[x+i][y].getCp()==null)
					units[x+i][y].setValidMove(true);
				else break;
			}

			if(x+1<8 && y+1<8 &&units[x][y].oppT(units[x+1][y+1])){
				units[x+1][y+1].setValidMove(true);
			}

			if(y-1>=0&& x+1<8 && units[x][y].oppT(units[x+1][y-1])){
				units[x+1][y-1].setValidMove(true);
			}
			
		}
		
		if(player==Player.WHITE){

			for(int i =1;i<3;i++){
				if(x-i>=0 && units[x-i][y].getCp()==null)
					units[x-i][y].setValidMove(true);
				//stops intermediately when a unit in front is not valid
				else break;
			}

			if(x-1>=0 && y-1>=0 &&units[x][y].oppT(units[x-1][y-1])){
				units[x-1][y-1].setValidMove(true);
			}

			if(x-1>=0 &&y+1<8 && units[x][y].oppT(units[x-1][y+1])){
				units[x-1][y+1].setValidMove(true);
			}
			
		}
		return true;
	}
	
	public boolean validCheckMateMoves(Player player){
		
		units = Board.getUnit();
		if(player==Player.BLACK){
			

			if(x+1<8 && y+1<8 && !units[x][y].oppTK(units[x+1][y+1])&& !units[x][y].sameT(units[x+1][y+1])){
				units[x+1][y+1].setCheckMateMove(true);
			}

			if(y-1>=0&& x+1<8 && !units[x][y].oppTK(units[x+1][y-1]) && !units[x][y].sameT(units[x+1][y-1])){
				units[x+1][y-1].setCheckMateMove(true);
			}
			
		}
		
		if(player==Player.WHITE){
			

			if(x-1>=0 && y-1>=0 && !units[x][y].oppTK(units[x-1][y-1]) && !units[x][y].sameT(units[x-1][y-1])){
				units[x-1][y-1].setCheckMateMove(true);
			}

			if(x-1>=0 &&y+1<8 && !units[x][y].oppTK(units[x-1][y+1])&& !units[x][y].sameT(units[x-1][y+1])){
				units[x-1][y+1].setCheckMateMove(true);
			}
			
		}
		
		return true;
	}
}
